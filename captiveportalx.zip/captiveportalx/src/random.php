<?php

echo(random_int(1000000000,9999999999));


?>